# fixadbroot
安装`magisk`之后 `adb root` 会报错
`adbd cannot run as root in production builds`
[参考链接](https://liwugang.github.io/2021/07/11/magisk_enable_adbr_root.html) 分析的很详细值得学习.
